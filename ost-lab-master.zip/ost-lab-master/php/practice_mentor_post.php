<?php
    include 'db_connection.php';
    $conn = OpenCon();

    $question = $_POST['question'];
    $description = $_POST['description'];
    $testcases = $_POST['testcases'];
    $outputs = $_POST['outputs'];
    $email = $_POST['email'];

    $sql = "INSERT INTO `practice` (`name`, `comments`, `testcases`, `outputs`, `description`, `email`) VALUES ('$question',DEFAULT,'$testcases','$outputs','$description','$email')";
    $result = $conn->query($sql) or die(mysql_error($conn));

    if($result){
       echo "Success!";
    } else {
        echo "Failure!";
    }
    $conn->close();
?>
