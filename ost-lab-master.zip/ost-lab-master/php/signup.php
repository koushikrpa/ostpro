<?php
    include 'db_connection.php';
    $conn = OpenCon();

    $email = $_POST['email'];
    $password = $_POST['pwd'];
    $username = $_POST['username'];
    $phone = $_POST['phone'];

    $sql = "INSERT INTO `student`(`name`, `email`, `password`, `phone`, `branch`, `year`, `section`, `image`) VALUES ('$username','$email','$password','$phone','CSE',4,'C',DEFAULT)";
    $result = $conn->query($sql);

    if($result){
       echo "Success!";
    } else {
        echo "Failure!";
    }
    $conn->close();
?>
