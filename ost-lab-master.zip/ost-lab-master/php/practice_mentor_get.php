<?php
include 'db_connection.php';
$conn = OpenCon();

$email = $_GET['email'];
$result=mysqli_query($conn,"select name from practice where email = $email");
$results = array();
while($row=mysqli_fetch_array($result)){
  array_push($results,$row);
}
echo(json_encode($results));
$conn->close();
?>
