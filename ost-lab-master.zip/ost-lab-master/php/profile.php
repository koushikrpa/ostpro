<?php
include 'db_connection.php';
$conn = OpenCon();

$member = "";
$email = "";

if(empty($_SERVER['CONTENT_TYPE'])){
  $_SERVER['CONTENT_TYPE'] = "application/json";
}

if(isset($_POST['member'])){
  $member = $_POST['member'];
}

if(isset($_POST['email'])){
  $email = $_POST['email'];
}

if($member == 'student'){
  $result=mysqli_query($conn,"SELECT * FROM student WHERE email = '$email'");
}else{
  $result=mysqli_query($conn,"SELECT * FROM mentors WHERE email = '$email'");
}

$results = array();
while($row=mysqli_fetch_array($result)){
  array_push($results,$row);
}

echo(json_encode($results));
$conn->close();
?>
