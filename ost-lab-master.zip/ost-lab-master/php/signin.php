<?php
    include 'db_connection.php';
    $conn = OpenCon();

    $email = $_POST['email'];
    $pwd = $_POST['pwd'];
    $table = $_POST['member'];

    $sql = "SELECT name FROM $table WHERE email='$email' AND password='$pwd'";
    $result = $conn->query($sql);

    $row = $result->fetch_assoc();

    if($row != null){
       echo "Success!";
    } else {
        echo "Failure!";
    }
    $conn->close();
?>
