$(document).ready(function(){

  var $question = localStorage.question;
  var $member = localStorage.member;

  console.log($member+" "+$question);

  if($member != "student"){
    setForMentor($question);
  }else{
    setForStudent($question,"hidden");
  }

  $("#submit").click(function(event){
    callApi(document.getElementById('editor').innerHTML);
  });
});

function setForStudent($question,$visibility){

  var request = new XMLHttpRequest();
  request.open('POST',"../ost-lab/php/codeeditor.php",true);
  request.setRequestHeader("Content-type", "application/json");
  request.onload = function() {
    console.log(request.responseText);
    var data = JSON.parse(request.responseText);
    document.getElementById('question').innerHTML = data[0][0];
    document.getElementById('description').innerHTML = data[0][4];
    document.getElementById('test_cases').innerHTML = data[0][2];
    document.getElementById('_output').innerHTML = data[0][3];
    $("#next").css("visibility",$visibility);
    if($visibility == "visible"){
      document.getElementById('next').value = 'UPDATE';
    }
  };
  request.onerror = function() {
    console.log("error!");
  };
  request.send("value="+$question);
}

function setForMentor($question){
  $("textarea").removeAttr('readonly');
  setForStudent($question,"visible");

  // UPDATE THE DETAILS BY POST REQUEST
}

function callApi($code) {
  $.post("https://api.jdoodle.com/v1/execute",{script: $code, language: "python", versionIndex: "1", clientId: "54f12c3f7391f8ebeb65aa871a97671a", clientSecret: "c440f18b1257e0d2072b9e707c5149b9e9ce6699631ac9135d965d1325e7a61c"}, function(data, status){
    console.log(data);
  },'json');

  var request = new XMLHttpRequest();
  request.open('POST',"https://api.jdoodle.com/v1/execute",true);
  request.setRequestHeader("Content-type", "application/json");
  request.onload = function () {
    console.log(request.responseText);
  };
  request.onerror = function () {
        console.log("Insecure connection");
  };
  request.send("script="+$code+"&language=python&versionIndex=1&clientId=54f12c3f7391f8ebeb65aa871a97671a&clientSecret=c440f18b1257e0d2072b9e707c5149b9e9ce6699631ac9135d965d1325e7a61c");
}
