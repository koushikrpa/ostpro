$(document).ready(function(){
  $.ajax({
    type: 'GET',
    url: "../ost-lab/php/practice_mentor_get.php",
    dataType: 'json',
    data: {email: localStorage.email},
    success: function (data) {
      $.each(data, function(index, element) {
        console.log(element.name);
        $(".posted").append('<li role="presentation"><a href="codeeditor.html">'+element.name+'</a></li>');
      });
    }
  });

  $(document).on("click","#post",function(){
    var $question = $("#question").val();
    var $description = $("#description").val();
    var $testcases = $("#testcases").val();
    var $outputs = $("#outputs").val();
    console.log($outputs);
    console.log($description);

    $.post("../ost-lab/php/practice_mentor_post.php",{question: $question, description: $description, testcases: $testcases, outputs: $outputs, email: localStorage.email},function(data){
        console.log(data);
        if(data == "Failure!"){
          alert("Failed!");
        }else{
          alert("Success!");
        }
      });
    });
  });
