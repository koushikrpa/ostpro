$(document).ready(function() {
  $.ajax({
    type: 'GET',
    url: "../ost-lab/php/practice_student.php",
    dataType: 'json',
    data: {value: 0},
    success: function (data) {
      $.each(data, function(index, element) {
        console.log(element.name);
        $(".unsolved").append('<li role="presentation"><a href="codeeditor.html">'+element.name+'</a></li>');
      });
    }
  });

  $.ajax({
    type: 'GET',
    url: "../ost-lab/php/practice_student.php",
    dataType: 'json',
    data: {value: 1},
    success: function (data) {
      $.each(data, function(index, element) {
        console.log(element.name);
        $(".solved").append('<li role="presentation"><a href="codeeditor.html">'+element.name+'</a></li>');
      });
    }
  });

  $(document).on("click","#logoutNav",function(){
    localStorage.email = "";
    document.location.href="/ost-lab";
  });

});
