$(document).ready(function(){

  if(localStorage.email != ""){
    setPage(localStorage.email, localStorage.member);
  }

  $(document).on("click","#loginNav",function(){
    $("login").modal();

    $(document).on("click","#loginSubmit",function(event){
      event.preventDefault();
      var $email = $("#signinEmail").val();
      var $password = $("signinPassword").val();

      $mentor = $email.split("@");
      var $member = "student";

      console.log($email);

      if($mentor[1] == "admin"){
        $member = "mentors";
      }else{
        $member = "student";
      }

      console.log($email);

      $.post("../ost-lab/php/signin.php",{email: $email, pwd: $password,member: $member},function(data){
        if(data == "Failure!"){
          alert("Failed!");
        }else{
          alert("Success!");
          $("#login").modal("toggle");
        }
      });

      setPage($email,$member);
    });
  });

  $(document).on("click","#registerNav",function(){
    $("register").modal();

    $(document).on("click","#registerSubmit",function(event){
      event.preventDefault();

      var $email = $("#registerEmail").val();
      var $password = $("#registerPassword").val();
      var $username = $("#username").val();
      var $phone = $("#phone").val();

      console.log("Here!");

      $.post(
        "../ost-lab/php/signup.php",
        {email: $email, pwd: $password, username: $username, phone: $phone},
        function(data){
          console.log(data);
          if(data == "Failure!"){
            alert("Failed!");
          }else{
            alert("Success!");
            setAfterRegistration($email,"student");
          }
        });
      });
    });

  $(document).on("click","#logoutNav",function(){
    makeInvisible();
    setLocalStore("","");
  });
});

function setPage($email, $member){
  setLocalStore($email,$member);
  makeVisible($member);
}

function setAfterRegistration($email, $member) {
  setLocalStore($email, $member);
  setPage($email, $member);
}

function setLocalStore($email, $member){
  localStorage.email = $email;
  localStorage.member = $member;
  console.log($member);
}

function makeVisible($member){
  $("#loginNav").remove();
  $("#registerNav").css("visibility","hidden");
  $(".practice").css("visibility","visible");
  $(".competition").css("visibility","visible");
  $(".profile").css("visibility","visible");
  $(".navbar-right").append('<li><button type="button" id="logoutNav" class="btn btn-info btn-lg"><span id="loginMenu">Logout</span></button></li>');

  if($member != "mentors"){
    $(".practice").attr('href','practice_student.html');
    $(".competition").attr('href','competition_student.html');
  }else{
    $(".practice").attr('href','practice_mentor.html');
    $(".competition").attr("href",'competition_mentor.html');
  }
}

function makeInvisible() {
  $("#registerNav").css("visibility","visible");
  $(".practice").css("visibility","hidden");
  $(".competition").css("visibility","hidden");
  $(".profile").css("visibility","hidden");
  $("#logoutNav").remove();
  $(".navbar-right").append('<li><button type="button" id="loginNav" class="btn btn-info btn-lg" data-toggle="modal" data-target="#login"><span id="loginMenu">Login</span></button></li>');
  alert("Logged out successfully!");
}
