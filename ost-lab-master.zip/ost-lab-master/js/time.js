
clock.innerHTML = '<span><input type=text name="start"> </span>'
                   + '<span> <input type=text name="dead"> </span>';