$(document).ready(function(){
  var $email = localStorage.email;
  var $member = localStorage.member;

  if($member!='student'){
    $member = "mentors";
  }

  var request = new XMLHttpRequest();
  request.open('POST',"../ost-lab/php/profile.php/",true);
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.onload = function () {
    var data = JSON.parse(this.responseText);
    console.log(data[0][1]);
    $('.name').text(data[0][1]);
    if($member == 'student'){
      $('.position').text('Student @Anits Engineering College');
    }else{
      $('.position').text('Faculty @Anits Engineering College');;
    }
  };
  request.onerror = function () {
    console.log("error!");

  };
  request.send("member="+$member+"&email="+$email);
});
